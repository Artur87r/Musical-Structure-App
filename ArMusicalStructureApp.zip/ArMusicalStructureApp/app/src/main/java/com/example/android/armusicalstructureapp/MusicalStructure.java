package com.example.android.armusicalstructureapp;

import android.app.Application;
import java.util.ArrayList;

public class MusicalStructure extends Application {

    private final ArrayList<com.example.android.armusicalstructureapp.Album> albums = new ArrayList<>();

    /**
     * Get Albums.
     */
    public ArrayList<com.example.android.armusicalstructureapp.Album> getAlbums() {
        return albums;
    }

    /**
     * Set Albums.
     */
    void addAlbum(com.example.android.armusicalstructureapp.Album album) {
        this.albums.add(album);
    }

    /**
     * Get Total Albums in ArrayList
     */
    public int getAlbumsCount() {
        if (albums == null) {
            return 0;
        }
        return albums.size();
    }

}
