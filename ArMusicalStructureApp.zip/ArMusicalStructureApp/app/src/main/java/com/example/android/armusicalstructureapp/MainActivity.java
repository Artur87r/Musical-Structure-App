package com.example.android.armusicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private static final int LOAD_ALL = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_main);

        // load Albums, Artists and Songs.
        if (((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbumsCount() == 0) {
            initializeAlbumInformation();
        }

        //Album activity_main.xml click listener
        LinearLayout albums = findViewById(R.id.album_layout);
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new intent to open the {@link AlbumsActivity}
                Intent albumsIntent = new Intent(MainActivity.this, com.example.android.armusicalstructureapp.AlbumsActivity.class);

                // Start the new activity
                startActivity(albumsIntent);
            }
        });

        //Artist activity_main.xml click listener
        LinearLayout artists = findViewById(R.id.artist_layout);
        artists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new intent to open the {@link ArtistsActivity}
                Bundle basket = new Bundle();
                basket.putInt("pos", LOAD_ALL);

                Intent artistsIntent = new Intent(MainActivity.this, com.example.android.armusicalstructureapp.ArtistsActivity.class);
                artistsIntent.putExtras(basket);
                // Start the new activity
                startActivity(artistsIntent);
            }
        });

        //Songs activity_main.xml click listener
        LinearLayout songs = findViewById(R.id.songs_layout);
        songs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new intent to open the {@link SongsActivity}
                Bundle basket = new Bundle();
                basket.putInt("pos", LOAD_ALL);

                Intent songIntent = new Intent(MainActivity.this, com.example.android.armusicalstructureapp.SongsActivity.class);
                songIntent.putExtras(basket);
                // Start the new activity
                startActivity(songIntent);
            }
        });

    }

    /**
     * Initialize Album/Artist/Song information
     */
    private void initializeAlbumInformation() {

        //add Albums
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("A Kysz!", 2018, "Daria Zawiałow", R.drawable.a_kysz));
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("Reset", 2017, "Pokahontaz", R.drawable.reset));
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("Mój dom", 2018, "Kortez", R.drawable.moj_dom));
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("Wiedza o Społeczeństwie", 2018, "Lao Che", R.drawable.wos));
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("Chapter One", 2018, "Gromee", R.drawable.chapter_one));
        ((MusicalStructure) this.getApplication()).addAlbum(new Album("Metal Ballads Vol.1", 2018, "Coma", R.drawable.metal));

        //add Albums Artists
        ((MusicalStructure) this.getApplication()).getAlbums().get(0).addArtist(new Artist("Daria Zawiałow","Rock", R.drawable.daria));
        ((MusicalStructure) this.getApplication()).getAlbums().get(1).addArtist(new Artist("Pokahontaz", "Hip Hop" , R.drawable.pocahontaz));
        ((MusicalStructure) this.getApplication()).getAlbums().get(2).addArtist(new Artist("Kortez", "Pop" , R.drawable.kortez));
        ((MusicalStructure) this.getApplication()).getAlbums().get(3).addArtist(new Artist("Lao Che", "Alternative" , R.drawable.lao_che));
        ((MusicalStructure) this.getApplication()).getAlbums().get(4).addArtist(new Artist("Gromee", "Pop" , R.drawable.gromee));
        ((MusicalStructure) this.getApplication()).getAlbums().get(5).addArtist(new Artist("Coma", "Rock" , R.drawable.coma));

        //add Albums Songs
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).getAlbumBand(), "Kundel Bury", 1, "00:03:23"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).getAlbumBand(), "Pistolet", 2, "00:03:49"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(0).getAlbumBand(), "Nie moc", 3, "00:03:20"));

        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).getAlbumBand(), "Z buta w drzwi", 1, "00:02:14"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).getAlbumBand(), "Nowy rozdział", 2, "00:03:09"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(1).getAlbumBand(), "Stawiam dziś", 3, "00:03:16"));

        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).getAlbumBand(), "Pierwsza", 1, "00:04:22"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).getAlbumBand(), "Dobrze, że Cię mam", 2, "00:03:32"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(2).getAlbumBand(), "Dobry moment", 3, "00:04:11"));

        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).getAlbumBand(), "Nie raj", 1, "00:05:06"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).getAlbumBand(), "Liczba mnoga", 2, "00:03:49"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(3).getAlbumBand(), "Spółdzielnia", 3, "00:03:52"));

        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).getAlbumBand(), "Fear Less", 1, "00:03:31"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).getAlbumBand(), "Lingo", 2, "00:03:16"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(4).getAlbumBand(), "Follow You", 3, "00:03:01"));

        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).getAlbumBand(), "Lajki", 1, "00:03:56"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).getAlbumBand(), "Proste decyzje", 2, "00:04:04"));
        ((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).addSong(new com.example.android.armusicalstructureapp.Song(((com.example.android.armusicalstructureapp.MusicalStructure) this.getApplication()).getAlbums().get(5).getAlbumBand(), "Uspokój sie", 3, "00:03:55"));
    }
}
