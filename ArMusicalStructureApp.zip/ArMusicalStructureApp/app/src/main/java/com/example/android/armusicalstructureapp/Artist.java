package com.example.android.armusicalstructureapp;

public class Artist {
    private final String artistName;
    private final String artistGenre;
    private final int mArtistImageResourceId;

    public Artist(String artistName, String artistGenre, int ArtistImageResourceId) {
        this.artistName = artistName;
        this.artistGenre = artistGenre;
        this.mArtistImageResourceId = ArtistImageResourceId;
    }

    public String getArtistName() {
        return artistName;
    }

    public String getArtistGenre() { return artistGenre; }

    public int getArtistImageResourceId() { return mArtistImageResourceId; }
}
