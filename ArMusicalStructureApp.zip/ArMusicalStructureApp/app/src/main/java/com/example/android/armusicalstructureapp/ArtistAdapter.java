package com.example.android.armusicalstructureapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class ArtistAdapter extends ArrayAdapter<com.example.android.armusicalstructureapp.Artist> {
    /**
     * Create a new {@link ArtistAdapter} object.
     *
     * @param context is the current context (i.e. Activity) that the adapter is being created in.
     * @param artists is the list of {@link Artist}s to be displayed.
     */
    public ArtistAdapter(Context context, ArrayList<com.example.android.armusicalstructureapp.Artist> artists) {
        super(context, 0, artists);
    }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ArtistAdapter.ViewHolder mainVH = null;

            // Check if an existing view is being reused, otherwise inflate the view
            View listItemView = convertView;
            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.list_artist, parent, false);

        // Get the {@link Artist} object located at this position in the list
        com.example.android.armusicalstructureapp.Artist currentArtist = getItem(position);

        // Find the TextView in the list_artist.xml layout with the ID artist_text_view and set value.
        TextView artistTextView = listItemView.findViewById(R.id.artist_text_view);
        artistTextView.setText(currentArtist.getArtistName());

        // Find the TextView in the list_artist.xml layout with the ID genre_text_view and set value.
        TextView genreTextView = listItemView.findViewById(R.id.genre_text_view);
        genreTextView.setText(currentArtist.getArtistGenre());

        // Find the ImageView in the list_artist.xml layout with the ID artist_image_view and set value.
        ImageView iconView = listItemView.findViewById(R.id.artist_image_view);
        iconView.setImageResource(currentArtist.getArtistImageResourceId());

        // Find the Button in the list_artist.xml layout with ID song_btn and store it in the tag and create listener.
        final ArtistAdapter.ViewHolder vh = new ArtistAdapter.ViewHolder();
        vh.position = position;
        vh.buttonSongs = listItemView.findViewById( R.id.song_btn);
        vh.buttonSongs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new intent to open the {@link Artists Activity}
                Bundle basket = new Bundle();
                basket.putInt("pos", position);
                Intent songIntent = new Intent(getContext(), SongsActivity.class);
                songIntent.putExtras(basket);
                // Start the new activity
                getContext().startActivity(songIntent);
            }
        });

        listItemView.setTag(vh);

    } else {
        mainVH = (ArtistAdapter.ViewHolder) convertView.getTag();
    }

        return listItemView;
}

class ViewHolder {
    int position;
    Button buttonSongs;
}

}
