package com.example.android.armusicalstructureapp;

public class Song {
    private final String songName;
    private final String band ;
    private final int trackNumber;
    private final String duration;

    public Song(String band, String songName, int trackNumber, String duration) {
        this.songName = songName;
        this.band = band;
        this.trackNumber = trackNumber;
        this.duration = duration;
    }

    public String getSongName() {
        return songName;
    }

    public String getArtistName() {
        return band;
    }

    public int getTrackNumber() { return trackNumber; }

    public String getDuration() {
        return duration;
    }
}
