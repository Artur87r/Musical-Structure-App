package com.example.android.armusicalstructureapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class AlbumAdapter extends ArrayAdapter<com.example.android.armusicalstructureapp.Album> {

    /**
     * Create a new {@link AlbumAdapter} object.
     *
     * @param context is the current context (i.e. Activity) that the adapter is being created in.
     * @param albums  is the list of {@link Album}s to be displayed.
     */
    public AlbumAdapter(Context context, ArrayList<com.example.android.armusicalstructureapp.Album> albums) {
        super(context, 0, albums);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder mainVH = null;

        // Check if an existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_album, parent, false);

            // Get the {@link Album} object located at this position in the list
            com.example.android.armusicalstructureapp.Album currentAlbum = getItem(position);

            // Find the TextView in the list_album.xml layout with the ID title_text_view and set value.
            TextView titleTextView = listItemView.findViewById(R.id.title_text_view);
            titleTextView.setText(currentAlbum.getAlbumTitle());

            // Find the TextView in the list_album.xml layout with the ID year_text_view and set value.
            TextView yearTextView = listItemView.findViewById(R.id.year_text_view);
            yearTextView.setText(Integer.toString(currentAlbum.getAlbumYear()));

            // Find the TextView in the list_album.xml layout with the ID band_text_view and set value.
            TextView bandTextView = listItemView.findViewById(R.id.band_text_view);
            bandTextView.setText(currentAlbum.getAlbumBand());

            // Find the ImageView in the list_album.xml layout with the ID album_image_view and set value.
            ImageView iconView = (ImageView) listItemView.findViewById(R.id.album_image_view);
            iconView.setImageResource(currentAlbum.getAlbumImageResourceId());

            // Find the Button in the list_album.xml layout with ID song_btn and store it in the tag and create listener.
            final ViewHolder vh = new ViewHolder();
            vh.position = position;
            vh.buttonSongs = listItemView.findViewById( R.id.song_btn);
            vh.buttonSongs.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Create a new intent to open the {@link AlbumsActivity}
                    Bundle basket = new Bundle();
                    basket.putInt("pos", position);
                    Intent songIntent = new Intent(getContext(), SongsActivity.class);
                    songIntent.putExtras(basket);
                    // Start the new activity
                    getContext().startActivity(songIntent);
                }
            });

            listItemView.setTag(vh);

        } else {
            mainVH = (ViewHolder) convertView.getTag();
        }

        return listItemView;
    }

    class ViewHolder {
        int position;
        Button buttonSongs;
    }

}
