package com.example.android.armusicalstructureapp;

import java.util.ArrayList;

public class Album {
    private final String albumTitle;
    private final int albumYear;
    private final String albumBand;
    private final int mAlbumImageResourceId;

    private final ArrayList<com.example.android.armusicalstructureapp.Song> songs = new ArrayList<>();
    private final ArrayList<Artist> artists = new ArrayList<>();

    Album(String albumTitle, int albumYear, String albumBand, int AlbumImageResourceId) {
        this.albumTitle = albumTitle;
        this.albumYear = albumYear;
        this.albumBand = albumBand;
        this.mAlbumImageResourceId = AlbumImageResourceId;
    }

    /**
     * Get Album Title.
     */
    public String getAlbumTitle() {
        return albumTitle;
    }

    /**
     * Get Album Year.
     */
    public int getAlbumYear() {
        return albumYear;
    }

    /**
     * Get Album Band.
     */
    public String getAlbumBand() {
        return albumBand;
    }
    /**
     * Get Album image.
     */

    public int getAlbumImageResourceId() { return mAlbumImageResourceId; }

    /**
     * Get Total Artists in Album.
     */
    public int getArtistCount() {
        if (artists == null) {
            return 0;
        }
        return artists.size();
    }


    /**
     * Get Total Songs in Album.
     */
    public int getSongsCount() {
        if (songs == null) {
            return 0;
        }
        return songs.size();
    }

    /**
     * Get Album Artists.
     */
    public ArrayList<Artist> getArtists() {
        return artists;
    }

    /**
     * Set Albums Artists.
     */
    void addArtist(Artist artist) {
        this.artists.add(artist);
    }

    /**
     * Get Album Songs.
     */
    public ArrayList<com.example.android.armusicalstructureapp.Song> getSongs() {
        return songs;
    }

    /**
     * Set Albums Songs.
     */
    void addSong(com.example.android.armusicalstructureapp.Song song) {
        this.songs.add(song);
    }


}
